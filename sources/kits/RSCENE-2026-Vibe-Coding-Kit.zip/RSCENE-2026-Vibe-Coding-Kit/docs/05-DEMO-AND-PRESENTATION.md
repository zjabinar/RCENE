# 05 — Demo and Presentation

## The demo formula

Use:

```text
PROBLEM → USER → AI → DECISION → ACTION → IMPACT
```

## Three-minute example

### 0:00–0:30 — Problem

Explain the operational pain in one sentence.

### 0:30–1:00 — User

Show who uses the application.

### 1:00–1:45 — AI

Enter realistic data.

Click Analyze.

Show structured AI result.

### 1:45–2:30 — Action

Accept/reject recommendation.

Generate report, notification, assignment, or other action.

### 2:30–3:00 — Impact

Show:

- time saved
- prioritized work
- improved visibility
- reduced manual processing
- decision support

Use measured results only if they are actually measured. Otherwise label them
as targets, estimates, or demo metrics.

## Demo design rules

Do:

- prepare realistic records
- keep one primary scenario
- use large readable text
- pre-seed data
- minimize navigation
- keep backup screenshots/video

Do not:

- start with login
- browse randomly
- type long text live if avoidable
- depend on a slow API
- demonstrate unfinished features
- apologize for unfinished features

## Demo route

Create:

```text
/demo
```

The demo route should provide a controlled, repeatable sequence.

## Presenter fallback

If the live app fails:

1. explain the intended workflow
2. use screenshots/video
3. show the local demo mode
4. continue the story

Never spend the whole presentation debugging.
