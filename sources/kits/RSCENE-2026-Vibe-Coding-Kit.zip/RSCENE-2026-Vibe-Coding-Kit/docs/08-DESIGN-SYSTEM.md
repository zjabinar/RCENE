# 08 — Competition Design System

## Design principle

Use a consistent visual language rather than allowing AI to invent a new style
on every page.

## Recommended direction

Modern civic-tech / smart-community interface:

- clean
- high contrast
- readable
- dashboard-oriented
- restrained use of gradients
- consistent iconography
- clear status colors
- strong hierarchy

## Theme presets

### Government

- primary: blue/cyan family
- background: light neutral or deep navy
- accent: cyan

### AI Innovation

- dark background
- bright cyan/purple accent
- restrained glow

### Community / Sustainability

- blue/green family
- warm neutral surfaces

## Component rules

Every page should reuse:

- AppShell
- Sidebar
- Topbar
- PageHeader
- StatCard
- DataTable
- StatusBadge
- EmptyState
- LoadingState
- ErrorState
- Modal/Dialog
- AIInsightCard
- Timeline
- ChartCard

## UX rules

- Primary action is visually obvious.
- Avoid more than one competing primary button.
- Tables need empty/loading/error states.
- Forms need validation feedback.
- AI results must be scannable.
- Important status should not depend on color alone.
- Use icons consistently.
- Keep mobile behavior intentional.

## AI result visual pattern

```text
┌──────────────────────────────────┐
│ AI ANALYSIS          HIGH         │
├──────────────────────────────────┤
│ Summary                          │
│ ...                              │
│                                  │
│ Key findings                     │
│ • ...                            │
│ • ...                            │
│                                  │
│ Recommended action               │
│ [ Approve Action ]               │
└──────────────────────────────────┘
```
