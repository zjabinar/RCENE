# 07 — Skills You Need to Practice

## Tier 1 — Essential

### Product thinking

Convert a vague problem into:

```text
user
pain
workflow
MVP
AI advantage
impact
```

### Prompting

Use:

```text
context
objective
constraints
acceptance criteria
```

### Debugging

Understand:

- TypeScript errors
- browser console
- HTTP status codes
- API errors
- environment variables
- dependency errors

### Git

Know:

```bash
git status
git diff
git add .
git commit
git log
git restore
```

### Web fundamentals

Know:

- HTTP
- REST
- JSON
- forms
- state
- API requests
- environment variables

## Tier 2 — High value

- TypeScript
- React/Next.js basics
- Tailwind
- SQL basics
- schema validation
- structured AI output
- prompt design
- UX judgment

## Tier 3 — Nice to have

- RAG
- embeddings
- MCP
- local LLMs
- background jobs
- advanced GIS

Do not spend the final preparation hours learning Tier 3.

## Most important human skill

Scope control.

You need to be willing to tell Claude:

> "No. That feature is not worth the remaining time."

AI can generate code faster than you can evaluate it. Your job is to choose
what deserves to exist.
