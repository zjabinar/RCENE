# 02 — Four-Hour Competition Runbook

## Rule zero

Do not confuse coding activity with competition progress.

Competition progress means:

> a judge can understand the problem, operate the app, see AI provide value,
> and understand the practical impact.

---

## Phase 0 — 0:00–0:10

### Decide

Write down:

```text
Problem:
Target user:
Current pain:
Our solution:
AI advantage:
One killer feature:
```

No coding rabbit hole.

---

## Phase 1 — 0:10–0:20

### Plan

Create:

- `PROJECT_BRIEF.md`
- `MVP.md`
- `DEMO_SCRIPT.md`

Define only:

- 3–5 screens
- 1 primary workflow
- 1–2 meaningful AI capabilities
- 1 impact dashboard or result

---

## Phase 2 — 0:20–1:30

### Build the core workflow

Priority:

1. landing/dashboard
2. main record/input
3. processing
4. result
5. action

Do not polish everything.

---

## Phase 3 — 1:30–2:20

### Add meaningful AI

Use structured output.

Example:

```json
{
  "classification": "HIGH_PRIORITY",
  "confidence": 0.91,
  "summary": "...",
  "recommended_actions": [
    "...",
    "..."
  ],
  "reasoning": [
    "..."
  ]
}
```

Do not display private chain-of-thought. Display concise reasons, evidence,
recommendations, and structured results.

---

## Phase 4 — 2:20–3:00

### Integrate

Connect:

- AI result
- data
- charts
- status
- activity log
- action buttons

Make the entire workflow demonstrable.

---

# FEATURE FREEZE — 3:00

From this point:

### Allowed

- bug fixes
- UI fixes
- responsive fixes
- loading states
- empty states
- demo-data corrections
- performance fixes
- presentation fixes

### Not allowed

- new major modules
- new architecture
- new framework
- second database
- new authentication system
- unrelated AI feature

---

## Phase 5 — 3:00–3:30

### UX polish

Fix:

- alignment
- typography
- whitespace
- button hierarchy
- labels
- empty states
- loading states
- error messages
- mobile layout
- chart readability

---

## Phase 6 — 3:30–3:45

### QA

Run:

```text
Home → Main workflow → AI → Result → Action → Dashboard
```

Test the fallback AI path.

Check browser console.

Check obvious broken links.

---

## Phase 7 — 3:45–3:55

### Presentation

Prepare:

- 1-minute problem explanation
- 2–3-minute demo
- 30-second impact statement
- poster screenshots

---

## Phase 8 — 3:55–4:00

### Freeze

Do not refactor.

Do not add features.

Do not "just try one thing".

Commit:

```bash
git add .
git commit -m "competition-final"
```

Then demonstrate.
