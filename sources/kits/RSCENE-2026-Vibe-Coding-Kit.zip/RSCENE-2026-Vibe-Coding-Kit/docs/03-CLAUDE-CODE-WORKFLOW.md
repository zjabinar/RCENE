# 03 — Claude Code Workflow

## Recommended structure

Use one main coding session and specialized agents for review/research.

```text
MAIN CLAUDE SESSION
       |
       +-- architect
       +-- ai-reviewer
       +-- ui-reviewer
       +-- qa
       +-- judge
```

Do not have several independent agents editing the same files simultaneously unless
you deliberately isolate them with Git worktrees.

## Main session responsibilities

The main session owns:

- architecture
- implementation
- integration
- final fixes
- commits

## Agent responsibilities

### architect

Read-only planning.

### ai-reviewer

Evaluate whether AI is meaningful and reliable.

### ui-reviewer

Review visual hierarchy and UX.

### qa

Find broken flows.

### judge

Score the project against the competition criteria.

## Recommended first prompt

```text
You are the lead developer for a 4-hour AI Vibe Coding Challenge.

Read CLAUDE.md, COMPETITION_RULES.md and the docs directory.

Do not code yet.

Inspect the repository and produce:
1. current architecture
2. reusable components
3. fastest MVP path
4. AI workflow
5. 4-hour implementation plan
6. top three risks

Wait for my approval before major implementation.
```

## Implementation prompt

```text
Implement the approved MVP.

Rules:
- reuse existing components
- avoid unnecessary dependencies
- preserve working code
- keep the demo path short
- implement meaningful AI
- maintain a deterministic demo fallback
- prioritize visible functionality
- stop before feature creep
```

## UI review prompt

```text
Review the application as a competition judge.

Do not redesign the entire app.

Identify only the five highest-impact visual/UX changes that can be completed
quickly. Then implement those changes without breaking the main workflow.
```

## QA prompt

```text
Act as a hostile competition tester.

Test the primary demo flow.

Find:
- broken buttons
- dead routes
- console errors
- bad loading states
- invalid data handling
- API failure behavior
- responsive issues

Fix only critical issues.
```

## Judge prompt

```text
Score this project against:
AI 20%
Innovation 20%
Functionality 20%
UX/UI 15%
Practical impact 15%
Presentation/poster 10%

Give:
1. current score
2. evidence
3. top three changes with highest expected score improvement
4. changes that should NOT be made because of time
```

## Session recovery

If the context becomes too large:

1. commit current work
2. create/update `STATUS.md`
3. start a fresh Claude session
4. instruct Claude to read:
   - `CLAUDE.md`
   - `STATUS.md`
   - `PROJECT_BRIEF.md`
   - `MVP.md`

This is safer than repeatedly explaining the project from memory.
