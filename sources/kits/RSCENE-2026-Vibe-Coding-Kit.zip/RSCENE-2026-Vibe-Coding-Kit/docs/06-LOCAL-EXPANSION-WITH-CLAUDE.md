# 06 — Expanding the Kit Locally With Claude Code

This file explains how to turn this documentation kit into a real application
starter without manually writing every component.

## Step 1 — Extract

Extract the ZIP into a local folder.

Example:

```text
C:\RSCENE2026\RSCENE-2026-Vibe-Coding-Kit
```

## Step 2 — Run preparation

PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\prepare-machine.ps1
```

The script performs local checks only. It does not install secrets.

## Step 3 — Expand documentation

```powershell
.\scripts\expand-kit.ps1
```

This creates/refreshes:

```text
generated/
  PROJECT-BRIEF.md
  MVP.md
  AI-WORKFLOW.md
  DEMO-SCRIPT.md
  POSTER-CONTENT.md
  STATUS.md
```

## Step 4 — Create a Git repository

```bash
git init
git add .
git commit -m "rscene competition baseline"
```

## Step 5 — Start Claude Code

From the repository root:

```bash
claude
```

## Step 6 — Ask Claude to expand the application

Paste:

```text
Read:
- CLAUDE.md
- COMPETITION_RULES.md
- docs/01-PREPARATION-PLAN.md
- docs/02-FOUR-HOUR-RUNBOOK.md
- docs/04-AI-ARCHITECTURE.md
- generated/PROJECT-BRIEF.md
- generated/MVP.md

Build the reusable competition starter.

Requirements:
- Next.js + TypeScript
- reusable responsive UI
- dashboard
- forms
- tables
- charts
- AI provider abstraction
- live provider placeholder
- deterministic demo provider
- /demo route
- seed data
- consistent design system
- no authentication unless required
- no unnecessary backend complexity

First inspect the existing files and propose a plan.
Then implement in small verified steps.
```

## Step 7 — Add your own project

When the competition problem becomes known:

```text
Read the project brief.

Adapt the starter to this problem.

Keep the existing design system and reusable infrastructure.

Implement only the smallest complete workflow that can score highly.
```

## Step 8 — Generate a scenario

Use:

```powershell
.\scripts\new-scenario.ps1 -Name "MyIdea"
```

Then ask Claude:

```text
Read scenarios/MyIdea.

Turn it into a competition-ready MVP.
Do not implement secondary features until the primary workflow works.
```

## Step 9 — Expand the kit further

Use this prompt:

```text
Audit this competition kit for missing reusable capabilities.

Do not change the existing philosophy.

Suggest additions in these categories:
- reusable UI
- AI workflows
- demo reliability
- QA
- presentation
- local offline fallback

For each suggestion estimate:
- build time
- score impact
- risk

Only implement suggestions with high score impact and low risk.
```

## Step 10 — Create a project-specific copy

For the actual competition project, make a separate Git repository/copy.

Do not modify your golden baseline directly.

Recommended:

```text
RSCENE-KIT-GOLDEN/
RSCENE-2026-PROJECT/
```

The golden kit is your emergency reset point.
