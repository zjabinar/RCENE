# 01 — Preparation Plan

## A. Day-before objective

Your machine should be able to create or open a working project without downloading
large amounts of tooling during the event.

Prepare:

- laptop fully charged
- charger
- extension/power adapter
- mouse if preferred
- backup USB drive
- local copy of this kit
- Git installed
- Node.js LTS installed
- package manager ready
- Claude Code authenticated
- browser installed
- VS Code installed
- local project template tested
- API keys stored in a secure local `.env` file
- fallback/demo AI tested
- sample datasets available offline

## B. Validate the development environment

Run:

```powershell
node --version
npm --version
git --version
claude --version
```

If using pnpm:

```powershell
pnpm --version
```

If using Python for utilities:

```powershell
python --version
```

## C. Create a clean Git baseline

Inside the competition repository:

```bash
git init
git add .
git commit -m "competition-ready baseline"
```

The baseline is your emergency rollback point.

## D. Prepare environment variables

Use `.env.local` or the equivalent:

```text
AI_PROVIDER=demo
AI_API_KEY=
DATABASE_URL=
NEXT_PUBLIC_APP_NAME=Smart Community AI
```

Do not commit secrets.

## E. Prepare three concept seeds

Do not fully build all three.

Prepare enough understanding to adapt quickly:

1. AI DRRM Situation Intelligence
2. AI Barangay Action Center
3. AI Tourism Intelligence

See `scenarios/`.

## F. Prepare a reusable visual system

Decide before the event:

- typography
- card radius
- button style
- spacing
- icon family
- chart style
- status colors
- page layout
- responsive behavior

The UI should look like one coherent product.

## G. Prepare a reusable AI pattern

The preferred pattern is:

```text
Input
  ↓
Validation
  ↓
AI analysis
  ↓
Structured JSON
  ↓
Human-readable UI
  ↓
Recommended action
  ↓
User confirmation
  ↓
Recorded result
```

## H. Practice the 3-minute demo

Practice until you can demonstrate:

- problem
- input
- AI
- decision
- action
- impact

without reading from notes.

## I. Practice failure recovery

Simulate:

- API unavailable
- Internet unavailable
- empty dataset
- slow AI response
- invalid form input
- browser refresh
- accidental navigation

The application should still have a safe demo path.
