# 04 — AI Architecture

## Goal

AI must be a significant part of the solution, not merely a chatbot placed on a page.

## Preferred architecture

```text
User input
   ↓
Application validation
   ↓
Prompt/context builder
   ↓
AI provider
   ↓
Structured output
   ↓
Schema validation
   ↓
UI result
   ↓
Human action
```

## Provider abstraction

Use:

```text
AI_PROVIDER=live
AI_PROVIDER=demo
```

Possible future extension:

```text
AI_PROVIDER=local
AI_PROVIDER=openai
AI_PROVIDER=anthropic
AI_PROVIDER=gemini
```

Do not add all providers during the competition unless needed.

## AI capabilities

Prefer these:

### Classification

Turn unstructured text into categories.

### Summarization

Turn long material into a concise briefing.

### Recommendation

Suggest next actions.

### Extraction

Turn documents/reports into structured fields.

### Report generation

Produce a concise decision-ready report.

## AI response contract

Prefer machine-readable JSON:

```json
{
  "status": "success",
  "classification": "HIGH",
  "summary": "Short summary.",
  "key_findings": [
    "Finding 1",
    "Finding 2"
  ],
  "recommended_actions": [
    "Action 1",
    "Action 2"
  ],
  "confidence": 0.88
}
```

Validate this response before rendering.

## Avoid chain-of-thought display

Do not ask the model to expose hidden reasoning.

Instead request:

- concise rationale
- evidence
- factors
- recommendations
- confidence where appropriate

## Demo provider

The demo provider should:

- be deterministic
- respond quickly
- produce realistic results
- use the same response schema as live AI
- require no network
- make the demo repeatable

## Example AI action loop

```text
Citizen report
      ↓
AI classifies
      ↓
AI scores priority
      ↓
AI recommends action
      ↓
Officer reviews
      ↓
Officer approves
      ↓
System records action
      ↓
Dashboard updates
```

This is stronger than:

```text
User → chatbot → paragraph
```
