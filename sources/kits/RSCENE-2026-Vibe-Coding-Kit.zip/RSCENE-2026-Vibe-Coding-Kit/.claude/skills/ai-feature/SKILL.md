# AI Feature Builder

Build meaningful AI capabilities using:

input → context → AI → structured output → validation → action.

Prefer classification, extraction, summarization, recommendation and report
generation over generic chat.

Provide a deterministic demo fallback.
