# Demo Data Generator

Generate realistic, internally consistent demo data.

Avoid Lorem Ipsum and Test User.

Use plausible Philippine/local-government/community context when appropriate.

Keep datasets small enough to load quickly.
