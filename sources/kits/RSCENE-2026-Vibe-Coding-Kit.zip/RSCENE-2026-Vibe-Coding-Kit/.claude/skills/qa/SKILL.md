# Competition QA

Test the primary demo path first.

Classify defects:

P0 — demo blocked
P1 — important
P2 — cosmetic

Fix P0/P1 first.
