# Poster Content Generator

Generate concise poster copy:

- problem
- solution
- AI workflow
- key features
- practical impact
- screenshots to capture

Avoid paragraphs when a diagram or short bullet would communicate better.
