# Competition Planner

Turn a challenge statement into:

- target user
- problem
- workflow
- MVP
- AI capability
- success metric
- demo scenario

Always optimize for four-hour completion.
