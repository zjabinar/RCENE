# Presentation Coach

Produce a concise presentation:

problem
solution
AI
workflow
impact

Keep the live demo focused on one memorable scenario.
