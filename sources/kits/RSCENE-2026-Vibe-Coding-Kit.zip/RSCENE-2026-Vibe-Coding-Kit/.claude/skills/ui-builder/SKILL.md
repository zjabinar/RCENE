# UI Builder

Use the existing design system.

Reuse components.

Every page should have:
- clear page header
- primary action
- loading state
- empty state
- error state
- responsive layout

Do not introduce a new visual language.
