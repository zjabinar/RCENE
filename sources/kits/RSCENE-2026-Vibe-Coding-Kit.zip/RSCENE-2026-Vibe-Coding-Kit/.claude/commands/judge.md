Use the rscene-judge.

Score the current project and recommend the top three score-improvement actions.
