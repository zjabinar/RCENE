FEATURE FREEZE.

Do not add new major functionality.

Inspect:
- demo path
- errors
- loading states
- responsive layout
- AI fallback
- presentation readiness

Only fix high-risk issues.
