Use the rscene-qa.

Test the primary demo flow.
Fix only P0/P1 issues unless explicitly told otherwise.
