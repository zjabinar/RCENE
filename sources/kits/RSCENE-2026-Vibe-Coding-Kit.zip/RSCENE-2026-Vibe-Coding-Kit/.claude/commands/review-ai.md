Use the rscene-ai-reviewer.

Review the AI implementation.
Return the five highest-impact improvements.
