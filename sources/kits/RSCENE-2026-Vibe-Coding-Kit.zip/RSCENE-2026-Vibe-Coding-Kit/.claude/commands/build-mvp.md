Read the approved project brief and MVP.

Implement the smallest complete workflow.

Do not add secondary features.
Reuse existing components.
Verify after each major step.
