Use the rscene-demo-coach.

Create:
- 3-minute script
- click sequence
- backup plan
- one-sentence impact statement
