Read CLAUDE.md and COMPETITION_RULES.md.

Act as the RSCENE architect.

Inspect the current repository.

Do not code.

Return:
- problem interpretation
- MVP
- AI capability
- pages
- data
- 4-hour plan
- top risks
