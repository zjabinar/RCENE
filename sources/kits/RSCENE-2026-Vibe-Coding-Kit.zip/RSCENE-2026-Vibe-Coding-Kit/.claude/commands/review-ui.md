Use the rscene-ui-reviewer.

Review the visible application.
Implement only high-impact improvements that are safe within the remaining time.
