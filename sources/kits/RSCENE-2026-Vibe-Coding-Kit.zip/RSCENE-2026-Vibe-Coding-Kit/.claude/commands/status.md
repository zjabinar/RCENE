Create or update STATUS.md.

Include:
- current working features
- known bugs
- current demo path
- next action
- feature freeze status
- Git commit
