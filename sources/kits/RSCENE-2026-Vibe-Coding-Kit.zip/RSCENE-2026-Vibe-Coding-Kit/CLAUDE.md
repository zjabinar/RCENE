# RSCENE 2026 — CLAUDE CODE MASTER CONSTITUTION

## Mission

Build a compelling, functional, AI-assisted smart-community web application
under a strict four-hour competition constraint.

The goal is not maximum code.

The goal is maximum demonstrated value per minute.

## Non-negotiable priorities

1. Working primary workflow
2. Meaningful AI
3. Practical impact
4. Strong UX/UI
5. Reliable demo
6. Presentation quality
7. Secondary features

## Engineering rules

- Inspect before editing.
- Reuse existing components.
- Do not duplicate components.
- Do not introduce a library unless it materially reduces risk/time.
- Do not rewrite working code without a strong reason.
- Keep the application easy to demonstrate.
- Prefer simple architecture.
- Prefer deterministic seed data.
- Validate AI structured output.
- Keep demo mode available.
- Never commit secrets.
- Keep environment configuration explicit.
- Test the primary path after major changes.

## Competition rules

At approximately 75% of available time, enforce feature freeze.

After feature freeze only:
- bug fixes
- UX fixes
- reliability
- demo
- poster
- presentation

## AI rules

AI must contribute to an actual task.

Good:

```text
classify → prioritize → recommend → act
```

Bad:

```text
chatbot → generic paragraph
```

Use structured outputs where possible.

Never expose private chain-of-thought. Display concise explanations, evidence,
confidence when appropriate, and recommended actions.

## Demo rules

The application must have a repeatable demo scenario.

Prefer:

```text
/demo
```

Do not make the demo depend on live external services.

## Scope rules

Before adding a feature ask:

- Does it improve the score?
- Does it solve the core problem?
- Can it be completed safely now?
- Can the judges see it?

If not, defer it.

## Code quality

Use:

- clear names
- small functions
- predictable file structure
- reusable components
- typed data
- validation
- accessible UI
- responsive layouts

## Emergency behavior

If a dependency fails:

1. diagnose
2. use existing fallback
3. avoid architectural rewrites
4. preserve the demo path

## Context recovery

If starting a new session, read:

1. `CLAUDE.md`
2. `STATUS.md` if present
3. `PROJECT_BRIEF.md`
4. `MVP.md`
5. relevant files

Then summarize current state before changing code.

## Default architecture

For competition-speed projects prefer:

```text
Next.js
TypeScript
Tailwind
Reusable UI primitives
Simple API layer
AI provider abstraction
Demo provider
Seed data
```

Use a database only when persistence improves the demonstration.

## Git discipline

Commit at milestones:

```text
baseline
mvp-working
ai-working
integration-working
competition-final
```

Never destroy the golden baseline.
