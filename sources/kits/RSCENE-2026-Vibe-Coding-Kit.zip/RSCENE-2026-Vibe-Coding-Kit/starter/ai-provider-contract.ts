// Blueprint contract. Adapt to your framework.
// Keep the interface stable so live/demo AI can be swapped without changing UI.

export type AIAnalysis = {
  status: "success" | "error";
  classification: string;
  summary: string;
  key_findings: string[];
  recommended_actions: string[];
  confidence?: number;
};

export interface AIProvider {
  analyze(input: unknown): Promise<AIAnalysis>;
}
