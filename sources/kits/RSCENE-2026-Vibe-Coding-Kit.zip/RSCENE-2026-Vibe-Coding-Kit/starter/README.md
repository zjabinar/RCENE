# Starter Application Blueprint

This folder intentionally contains a lightweight blueprint rather than a large
pre-generated framework. Use Claude Code to expand it into the actual Next.js app.

## Target structure

```text
app/
  page.tsx
  dashboard/page.tsx
  demo/page.tsx
  api/
    ai/route.ts

components/
  ui/
  layout/
  ai/
  dashboard/

lib/
  ai/
    provider.ts
    demo.ts
    live.ts
  data/
  validation/

public/
```

## Recommended first implementation

Build only:

1. App shell
2. Dashboard
3. One primary workflow
4. AI insight card
5. Demo mode
6. Demo route

Then add secondary components only if time remains.
