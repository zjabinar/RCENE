# RSCENE 2026 AI Vibe Coding Challenge — Expandable Coding Kit

This kit is designed for a 4-hour AI-assisted web application competition.

## Core strategy

Do NOT try to build an entire production system during the competition.

Instead:

1. Start from a prepared application shell.
2. Identify the smallest useful problem.
3. Build one complete end-to-end workflow.
4. Make AI a meaningful part of the workflow.
5. Polish the visible UX.
6. Freeze features early.
7. Demonstrate a compelling story.

The kit is deliberately domain-neutral. It can be adapted to LGU, DRRM, barangay,
tourism, public service, education, environment, business assistance, or other
smart-community concepts.

## What is included

- `CLAUDE.md` — master Claude Code operating constitution
- `COMPETITION_RULES.md` — competition-focused priorities and scorecard
- `docs/` — preparation, execution, AI, UX, demo, poster, QA and fallback playbooks
- `.claude/agents/` — specialized Claude Code subagents
- `.claude/skills/` — reusable skills/prompts
- `.claude/commands/` — slash-command prompt files
- `prompts/` — competition prompts you can paste directly
- `scenarios/` — ready-to-adapt concept seeds
- `templates/` — project brief, MVP, demo script, AI workflow, poster content
- `scripts/` — local preparation and expansion scripts
- `starter/` — minimal frontend starter blueprint and reusable patterns
- `checklists/` — day-before, venue, four-hour and final-demo checklists

## Important

This is a preparation kit, not a guarantee of winning. During the actual event,
follow the official organizers' current instructions and any challenge-specific
problem statement/rules announced at the venue.

## Quick start

### Windows PowerShell

```powershell
cd RSCENE-2026-Vibe-Coding-Kit

Set-ExecutionPolicy -Scope Process Bypass

.\scripts\prepare-machine.ps1
.\scripts\expand-kit.ps1
```

Then inspect:

```text
docs/01-PREPARATION-PLAN.md
docs/02-FOUR-HOUR-RUNBOOK.md
docs/03-CLAUDE-CODE-WORKFLOW.md
docs/04-AI-ARCHITECTURE.md
docs/05-DEMO-AND-PRESENTATION.md
```

If you have Claude Code installed, copy or adapt the `.claude/` directory into
your competition repository, then start Claude Code from the repository root.

## Recommended competition architecture

For a 4-hour challenge:

```text
Next.js + TypeScript
Tailwind CSS
shadcn/ui or equivalent reusable UI primitives
Optional PostgreSQL/Supabase
AI provider abstraction
Demo/fallback AI provider
Seed/demo data
One polished end-to-end workflow
```

Avoid unnecessary authentication, microservices, elaborate RBAC, or complex
infrastructure unless the problem explicitly requires them.

## AI provider safety

Never make the competition demo depend entirely on a live API.

Use:

```text
LIVE  -> real AI provider
DEMO  -> deterministic local responses
```

The application should remain demonstrable if an API key, network connection,
quota, or provider fails.

## Recommended time rule

Target:

```text
0:00–0:20  Problem + architecture
0:20–1:30  Core workflow
1:30–2:20  Meaningful AI feature
2:20–3:00  Integration + data
3:00       FEATURE FREEZE
3:00–3:30  UI/UX polish
3:30–3:45  QA
3:45–3:55  Poster/demo
3:55–4:00  Final smoke test
```

The exact schedule can be adjusted to the organizer's actual starting/ending
time.

## Expandability

The kit is intentionally designed so Claude Code can expand it locally.

Run:

```powershell
.\scripts\expand-kit.ps1
```

Then ask Claude Code:

```text
Read the entire RSCENE kit documentation.

Expand this kit with:
1. a reusable Next.js application shell,
2. reusable dashboard/table/form/chart components,
3. an AI provider abstraction with live and demo providers,
4. a /demo route,
5. seed data,
6. a design system,
7. automated smoke tests.

Do not add unnecessary dependencies.
Do not remove the competition guardrails.
```

See `docs/06-LOCAL-EXPANSION-WITH-CLAUDE.md` for the recommended expansion process.
