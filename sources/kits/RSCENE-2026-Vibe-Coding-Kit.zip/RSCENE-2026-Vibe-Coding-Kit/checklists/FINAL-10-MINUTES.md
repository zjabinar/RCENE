# Final 10 Minutes

STOP ADDING FEATURES.

- [ ] primary workflow works
- [ ] demo route works
- [ ] AI result works
- [ ] demo fallback works
- [ ] no obvious console errors
- [ ] no accidental test text
- [ ] buttons work
- [ ] charts readable
- [ ] poster ready
- [ ] screenshots ready
- [ ] presentation script ready
- [ ] final Git commit
