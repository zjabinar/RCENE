# Day-Before Checklist

## Laptop

- [ ] charger
- [ ] extension
- [ ] mouse
- [ ] backup USB
- [ ] enough disk space
- [ ] battery health checked

## Software

- [ ] Node.js
- [ ] Git
- [ ] VS Code
- [ ] Claude Code
- [ ] browser
- [ ] package manager
- [ ] project template tested

## Accounts

- [ ] Claude authenticated
- [ ] AI API key tested
- [ ] backup AI provider if intentionally used
- [ ] no secrets committed

## Project

- [ ] Git baseline
- [ ] app starts
- [ ] demo data works
- [ ] demo mode works
- [ ] /demo works
- [ ] screenshots captured
- [ ] poster draft ready

## Practice

- [ ] 3-minute demo
- [ ] 1-minute problem explanation
- [ ] 30-second impact statement
- [ ] failure recovery practiced
