# Venue Checklist

- [ ] connect to provided Internet
- [ ] verify speed
- [ ] verify power
- [ ] verify browser
- [ ] verify API access
- [ ] verify Claude Code authentication
- [ ] verify local project
- [ ] verify fallback demo
- [ ] create final Git branch/commit if desired
- [ ] start timer
- [ ] avoid unnecessary downloads
