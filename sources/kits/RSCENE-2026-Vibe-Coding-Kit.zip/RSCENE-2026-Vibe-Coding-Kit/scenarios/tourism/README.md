# Scenario — AI Tourism Intelligence

## Problem

Tourism information is distributed across visitor feedback, events and site data.

## User

Tourism officer.

## AI

- sentiment summary
- visitor trend extraction
- itinerary recommendation
- issue detection
- campaign recommendation

## Killer demo

Upload feedback → AI identifies concerns → recommends actions → dashboard updates.

## Defer

Real-time social media integrations.
