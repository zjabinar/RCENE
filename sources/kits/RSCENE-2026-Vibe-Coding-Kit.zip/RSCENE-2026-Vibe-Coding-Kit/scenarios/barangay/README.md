# Scenario — AI Barangay Action Center

## Problem

Community requests are manually classified and routed.

## User

Barangay/LGU staff.

## Input

Citizen request.

## AI

- classify
- prioritize
- identify office
- summarize
- recommend next action

## Killer demo

Citizen report → AI classification → office routing → action → status dashboard.

## Defer

Full citizen authentication.
