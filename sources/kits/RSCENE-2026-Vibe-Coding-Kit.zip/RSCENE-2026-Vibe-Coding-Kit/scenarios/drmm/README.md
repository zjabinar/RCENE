# Scenario — AI DRRM Situation Intelligence

## Problem

LGU/DRRM personnel receive multiple reports and need to prioritize response.

## User

DRRM officer / incident commander.

## Input

- incident report
- location
- severity indicators
- affected population
- weather/context

## AI

- classify incident
- assess priority
- summarize
- recommend response
- generate executive briefing

## Killer demo

Submit a flood report → AI identifies high priority → recommends actions →
officer approves → dashboard updates.

## Data

Use 5–10 incidents and 5 barangays.

## Defer

Real-time weather integrations unless already available.
