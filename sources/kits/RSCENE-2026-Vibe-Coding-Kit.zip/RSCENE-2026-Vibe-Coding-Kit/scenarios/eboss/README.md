# Scenario — AI Business Permit Assistant

## Problem

Business applicants are unsure which documents and steps apply to them.

## User

Business owner / frontline staff.

## AI

- identify business type
- infer likely requirements
- identify missing information
- produce checklist
- explain next steps

## Killer demo

User describes business → AI creates tailored checklist → missing documents
highlighted → next steps shown.

## Defer

Actual permit issuance unless already available.
