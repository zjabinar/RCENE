# Scenario — AI Executive Briefing

## Problem

Executives need concise decision-ready summaries from multiple reports.

## User

Mayor/President/office head/executive.

## Input

Department reports and KPIs.

## AI

- summarize
- extract risks
- identify trends
- recommend actions
- create executive briefing

## Killer demo

Select reports → generate briefing → show risks → recommended actions →
dashboard.

## Defer

Complex document ingestion if it cannot be made reliable within four hours.
