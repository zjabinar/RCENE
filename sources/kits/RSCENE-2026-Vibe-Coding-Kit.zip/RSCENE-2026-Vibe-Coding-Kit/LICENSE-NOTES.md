# License / Usage Notes

This preparation kit is provided as a project-planning and coding aid.

Before adding third-party libraries, templates, images, fonts, icons, datasets,
or code snippets to the competition project, review their licenses and usage
requirements.

Do not use copyrighted images or datasets without permission.

Prefer:
- your own assets
- permissively licensed assets
- official public-domain/open-data sources where appropriate
