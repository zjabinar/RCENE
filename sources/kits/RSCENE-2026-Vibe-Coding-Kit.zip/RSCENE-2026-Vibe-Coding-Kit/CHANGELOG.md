# Changelog

## 2026-10-06

Initial RSCENE 2026 competition preparation kit.

Includes:
- master Claude Code constitution
- specialized agents
- reusable skills
- commands
- preparation playbooks
- AI architecture
- demo/poster guidance
- scenario seeds
- local expansion scripts
- starter AI provider contract
