#!/usr/bin/env bash
set -e

mkdir -p generated
cp templates/PROJECT-BRIEF.md generated/
cp templates/MVP.md generated/
cp templates/AI-WORKFLOW.md generated/
cp templates/DEMO-SCRIPT.md generated/
cp templates/POSTER-CONTENT.md generated/
cp templates/STATUS.md generated/

echo "Kit expanded into generated/"
