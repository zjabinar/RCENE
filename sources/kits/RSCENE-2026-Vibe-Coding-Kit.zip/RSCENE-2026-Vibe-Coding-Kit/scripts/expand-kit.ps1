param(
    [string]$ProjectName = "Smart Community AI"
)

$ErrorActionPreference = "Stop"

$generated = Join-Path $PSScriptRoot "..\generated"
New-Item -ItemType Directory -Force -Path $generated | Out-Null

$files = @(
    "templates\PROJECT-BRIEF.md",
    "templates\MVP.md",
    "templates\AI-WORKFLOW.md",
    "templates\DEMO-SCRIPT.md",
    "templates\POSTER-CONTENT.md",
    "templates\STATUS.md"
)

foreach ($file in $files) {
    $source = Join-Path $PSScriptRoot "..\$file"
    $target = Join-Path $generated (Split-Path $file -Leaf)
    Copy-Item $source $target -Force
}

$status = Join-Path $generated "STATUS.md"
$stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
Add-Content $status "`r`n## Generated`r`n$stamp`r`n"

Write-Host ""
Write-Host "Kit expanded into generated/." -ForegroundColor Green
Write-Host "Next: open Claude Code and ask it to read CLAUDE.md and generated/ files."
