Write-Host "RSCENE 2026 Competition Environment Check" -ForegroundColor Cyan
Write-Host ""

$commands = @("node", "npm", "git", "claude", "python")

foreach ($cmd in $commands) {
    $found = Get-Command $cmd -ErrorAction SilentlyContinue
    if ($found) {
        Write-Host "[OK] $cmd -> $($found.Source)" -ForegroundColor Green
        try {
            & $cmd --version 2>$null | Select-Object -First 1
        } catch {}
    } else {
        Write-Host "[MISSING] $cmd" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "This script does not install software or modify credentials." -ForegroundColor Gray
Write-Host "Install missing tools before competition day."
