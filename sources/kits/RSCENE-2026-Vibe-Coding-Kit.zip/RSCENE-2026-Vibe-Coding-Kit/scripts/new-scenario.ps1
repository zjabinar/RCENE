param(
    [Parameter(Mandatory=$true)]
    [string]$Name
)

$base = Join-Path $PSScriptRoot "..\scenarios\$Name"
New-Item -ItemType Directory -Force -Path $base | Out-Null

@"
# Scenario — $Name

## Problem

## Target User

## Input

## AI Capability

## Primary Workflow

## Killer Demo

## Data

## Impact

## Deferred
"@ | Set-Content (Join-Path $base "README.md") -Encoding UTF8

Write-Host "Created scenario: $base" -ForegroundColor Green
