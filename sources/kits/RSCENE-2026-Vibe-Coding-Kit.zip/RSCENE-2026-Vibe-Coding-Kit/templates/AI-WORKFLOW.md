# AI Workflow

## Capability

## User Input

## Context

## Prompt

## Expected Structured Output

```json
{
  "status": "success",
  "classification": "",
  "summary": "",
  "key_findings": [],
  "recommended_actions": [],
  "confidence": 0
}
```

## Validation

## UI

## Human Approval

## Action Taken

## Demo Fallback

## Failure Behavior
