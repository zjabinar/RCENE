# Project Brief

## Project Name

## One-Sentence Pitch

## Problem

## Target User

## Current Workflow

## Pain Point

## Proposed Solution

## Why AI?

## Killer Feature

## Primary Workflow

```text
Input →
AI →
Insight →
Decision →
Action →
Impact
```

## Screens

1.
2.
3.
4.
5.

## Data

## Demo Scenario

## Expected Impact

## Out of Scope

