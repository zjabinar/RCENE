# Demo Script

## Opening — 20–30 sec

Problem:

## User — 20 sec

Who uses the system:

## Input — 20–30 sec

Show:

## AI — 45 sec

Click:

Expected result:

## Action — 45 sec

Click:

Result:

## Impact — 30 sec

Key benefit:

## Backup

If live AI fails:
