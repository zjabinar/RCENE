# MVP

## Must Work

- [ ] Landing/dashboard
- [ ] Main input
- [ ] Main workflow
- [ ] AI capability
- [ ] Result
- [ ] Action
- [ ] Impact/result view
- [ ] Demo route

## Nice to Have

- [ ] Export
- [ ] Map
- [ ] Notifications
- [ ] Additional analytics

## Explicitly Deferred

-

## Feature Freeze Time

Target: 75% of competition time.
