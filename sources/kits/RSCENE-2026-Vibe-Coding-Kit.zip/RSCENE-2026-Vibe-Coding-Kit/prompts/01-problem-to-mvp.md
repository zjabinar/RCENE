Convert this challenge/problem into a four-hour MVP.

Return:

# Problem
# Target User
# Current Pain
# Proposed Solution
# AI Advantage
# Primary Workflow
# 3–5 Screens
# Data Needed
# Demo Scenario
# Success/Impact Metric
# Features to Defer

Hard rule:
One complete workflow is more important than many incomplete modules.
