Act as a strict competition judge.

Score:
AI 20
Innovation 20
Functionality 20
UX/UI 15
Practical impact 15
Presentation/poster 10

Return:
- score
- evidence
- biggest weakness
- top three improvements
- features to avoid adding
