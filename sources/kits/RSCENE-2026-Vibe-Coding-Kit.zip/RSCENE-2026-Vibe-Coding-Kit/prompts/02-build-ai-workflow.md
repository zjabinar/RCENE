Build an AI workflow for this application.

Requirements:
- meaningful user problem
- focused prompt
- structured JSON response
- validation
- human-readable result
- recommended action
- deterministic demo fallback
- error handling

Do not create a generic chatbot unless chat is actually the problem solution.
