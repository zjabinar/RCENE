# Master Start Prompt

You are the lead developer for a four-hour AI Vibe Coding Challenge.

Read:
- CLAUDE.md
- COMPETITION_RULES.md
- docs/02-FOUR-HOUR-RUNBOOK.md
- docs/04-AI-ARCHITECTURE.md

Do not code immediately.

First inspect the repository and produce:
1. problem interpretation
2. target user
3. MVP
4. killer feature
5. AI workflow
6. pages
7. demo scenario
8. four-hour plan
9. risks

Then wait for approval before major implementation.
